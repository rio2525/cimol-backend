
import express from 'express';
const app = express();
app.get('/', (_, res) => res.send('CIMOL Backend Online'));
app.listen(4000, () => console.log('Backend running'));
